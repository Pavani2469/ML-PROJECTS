from flask import Flask, render_template, request
import pickle
import numpy as np
app = Flask(__name__)
model = pickle.load(open("modeldd.pkl",'rb'))
@app.route('/')
def home():
    return render_template("index.html")
@app.route('/predict', methods=['GET','POST'])
def predict():
    if request.method=='POST':
        tumor=request.form["tumor"] 
        age=request.form["age"]
        arr=np.array([int(tumor),int(age)])
        pred=model.predict([arr])
        pred=int(pred)
        if pred == 0:
            
            pred_text = "is going to survive "
            prevention_tips = ["Keep a healthy weight.",
                               "Be physically active.",
                               "Choose not to drink alcohol, or drink alcohol in moderation.",
                               "If you are taking, or have been told to take, hormone replacement therapy or oral contraceptives (birth control pills), ask your doctor about the risks and find out if it is right for you.",
                               "Breastfeed your children, if possible.",
                               "If you have a family history of breast cancer or inherited changes in your BRCA1 and BRCA2 genes, talk to your doctor about other ways to lower your risk."]
        else:
            pred_text = "not survive more"
            prevention_tips = ["Consider regular screenings and early detection methods such as mammograms.",
                               "Maintain a healthy lifestyle with balanced nutrition and regular exercise.",
                               "Avoid tobacco and limit alcohol consumption.",
                               "Discuss preventive measures and genetic testing options with your healthcare provider."]

        return render_template("index.html", data=pred_text, tips=prevention_tips)
if __name__ == '__main__':
    app.run(port=8000,debug=True)