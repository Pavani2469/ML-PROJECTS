import pandas as pd
 
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.metrics import accuracy_score, classification_report
import pickle

# Load the dataset
df = pd.read_csv(r'Breast_Cancer.csv')

# Select relevant columns
columns = ['Age', 'Tumor Size', 'Status']
df = df[columns] 

# Preprocessing: Encoding categorical variables
label_encoder = LabelEncoder()
df['Status'] = label_encoder.fit_transform(df['Status'])

# Splitting the data into training and testing sets
X = df[['Age', 'Tumor Size']]
y = df['Status']
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=42)

# Standardize the features
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# Train the model
lr = LinearRegression()
lr.fit(X_train_scaled, y_train)

# Save the trained model
pickle.dump(lr, open('modeldd.pkl', 'wb'))

# Model Evaluation
y_pred_train = lr.predict(X_train_scaled)
y_pred_test = lr.predict(X_test_scaled)

# Convert predictions to binary labels (0 or 1)
y_pred_train_binary = [1 if val >= 0.5 else 0 for val in y_pred_train]
y_pred_test_binary = [1 if val >= 0.5 else 0 for val in y_pred_test]

# Calculate accuracy
train_accuracy = accuracy_score(y_train, y_pred_train_binary)
test_accuracy = accuracy_score(y_test, y_pred_test_binary)

print(f"Training Accuracy: {train_accuracy:.2f}")
print(f"Testing Accuracy: {test_accuracy:.2f}")

# Classification Report
print("Classification Report for Training Set:")
print(classification_report(y_train, y_pred_train_binary))

print("Classification Report for Testing Set:")
print(classification_report(y_test, y_pred_test_binary))

# Prediction on New Data
new_data = pd.DataFrame({'Age': [45, 55], 'Tumor Size': [2, 3]})
new_data_scaled = scaler.transform(new_data)

new_data_predictions = lr.predict(new_data_scaled)
new_data_predictions_binary = [1 if val >= 0.5 else 0 for val in new_data_predictions]

print("Predictions on New Data:")
print(new_data_predictions_binary)
